var num1 =7;
var num2 =8;

var resultado= num1*num2;

if(resultado > 36){
	console.log("Parabens!");
}else{
	console.log("Menor que 36");
}